package com.niki;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.w3c.dom.Element;

import com.sun.syndication.feed.rss.Image;
import com.sun.syndication.feed.synd.SyndContent;
import com.sun.syndication.feed.synd.SyndEnclosure;
import com.sun.syndication.feed.synd.SyndEntry;
import com.sun.syndication.feed.synd.SyndEntryImpl;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.feed.synd.SyndImage;
import com.sun.syndication.feed.synd.SyndImageImpl;
import com.sun.syndication.io.SyndFeedInput;
import com.sun.syndication.io.XmlReader;

public class RomeLibraryExample {
	public static void main(String[] args) throws Exception {

		// URL url = new URL("https://www.reddit.com/.rss");
		// HttpURLConnection httpcon = (HttpURLConnection) url.openConnection();
		// SyndFeedInput input = new SyndFeedInput();
		// SyndFeed feed = input.build(new XmlReader(httpcon));
		// List<SyndEntry> entries = feed.getEntries();

		// File f = new File("C:\\rssfeed.txt");
		// ObjectOutputStream outputStream = new ObjectOutputStream(new
		// FileOutputStream(f));
		// outputStream.writeObject(entries);
		// outputStream.flush();

		// Backend Code can see in eclipse console (This is offline/online)
		File f = new File("C:\\rssfeed.txt");
		List<SyndEntry> entries = (List<SyndEntry>) new ObjectInputStream(new FileInputStream(f)).readObject();

		// common code for bckend
		Iterator<SyndEntry> itEntries = entries.iterator();
		while (itEntries.hasNext()) {
			SyndEntry entry = itEntries.next();
			System.out.println("getTitle: " + entry.getTitle());
			System.out.println("getLink: " + entry.getLink());
			System.out.println("getAuthor: " + entry.getAuthor());
			System.out.println("getUri: " + entry.getUri());
			System.out.println("getCategories: " + entry.getCategories());
			System.out.println("getPublishedDate: " + entry.getPublishedDate());
			System.out.println("getUpdatedDate: " + entry.getUpdatedDate());
			List<SyndContent> ent = entry.getContents();
			for (SyndContent en : ent) {
				int findex = en.getValue().indexOf("<img");
				int lindex = en.getValue().lastIndexOf(".jpg");
				if (findex >= 0 && en.getValue().length() >= lindex && en.getValue().length() > findex) {
					String sub = en.getValue().substring(findex + 10, lindex + 4);
					System.out.println("getImagePath: " + sub);
				} else {
					System.out.println("getImagePath: null");
				}
			}
			System.out.println("==================Netesh===============================");
		}
	}

	public List<SyndEntry> feedGenerator() throws Exception {
		// Offline Reader Start
		File f = new File("C:\\rssfeed.txt");
		List<SyndEntry> entries = (List<SyndEntry>) new ObjectInputStream(new FileInputStream(f)).readObject();
		// Offline Reader End
		return entries;
	}

	// public List<SyndEntry> feedGenerator()throws Exception{
	//
	// URL url = new URL("https://www.reddit.com/.rss");
	// HttpURLConnection httpcon = (HttpURLConnection) url.openConnection();
	// SyndFeedInput input = new SyndFeedInput();
	// SyndFeed feed = input.build(new XmlReader(httpcon));
	// List<SyndEntry> entries = feed.getEntries();
	//
	// return entries;
	// }

}
